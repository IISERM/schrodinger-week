import pandas as pd
import numpy as np
df=pd.read_csv('Q3_data.csv')
del df['Name']
df.head()

x=df.to_numpy()

b = np.split(x,[11])
planet=b[0]
worm=b[1]
worm

list_of_bodies=['0','1','2','3','4','5','6','7','8','9','10','w1','w2','w3']

#distance between planets - dictionary

ppdict={}
for i in range(0,len(planet)):
  for j in range(i+1,len(planet)):
    d=np.linalg.norm(planet[j]-planet[i])
    p='+'
    ppdict[(str(i)+ p + str(j))]=d
print(len(ppdict))
print(ppdict)

#distance between planets (tuple)

ppdict={}
tup=[]
for i in range(0,len(planet)):
  for j in range(i+1,len(planet)):
    d=np.linalg.norm(planet[j]-planet[i])
    #p='+'
    t=(str(i),str(j),round(d,2))
    #ppdict[(str(i)+ p + str(j))]=d
    tup.append(t)
print(len(tup))
print(tup)

#distance between planets and wormholes

for i in range(len(planet)):
  for j in range(len(worm)):
      dpw=np.linalg.norm(planet[i]-worm[j])
      t=(str(i),('w'+str(j)),round(dpw,2))
      tup.append(t)
print(len(tup))
print(tup)

#distance between wormholes 

ww=[('w1','w2',0),('w1','w3',0),('w2','w3',0)]
for i in range(len(ww)):
  tup.append(ww[i])
print(len(tup))

list_of_bodies=['0','1','2','3','4','5','6','7','8','9','10']

import networkx as nx
G=nx.Graph()

#G.add_edges_from(tup)
#single_source_shortest_path_length(G, source)
