import numpy as np
import matplotlib.pyplot as plt

D = 30
r = 50
d = 0.2
kT = 1000
num_steps = 2*10**5
num_particles = 50

#E = D*((r/x)**12 - (r/x)**6)

initial_position = np.array([np.random.random(2)*4-2 for _ in range(num_particles)])

def energy_summ(pos):
	energy = 0
	for i in range(pos.shape[0]-1):
		for j in range(i+1,pos.shape[0]):
			dis = pos[i,:]-pos[j,:]
			dist = np.linalg.norm(dis)
			E = D*((r/dist)**12 - (r/dist)**6)
			energy = energy + E
	return energy

def displacement(pos):
	x = np.random.uniform(-d,d,(50,2))
	return (pos+x)

c=0
position = initial_position
for i in range(num_steps):
	old_ener = energy_summ(position)
	tmp = displacement(position)
	new_ener = energy_summ(tmp)
	if new_ener < old_ener:
		position = tmp
		print ('yo')
	else:
		pass
	if i%1000 == 0:
		c = c+1
		fig = plt.figure()
		plt.xlim(-10, 10) 
		plt.ylim(-10, 10) 
		plt.plot(position[:,0],position[:,1],'o')
		plt.savefig(str(c)+'.png')
		plt.close()
