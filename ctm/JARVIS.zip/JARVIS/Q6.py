import random
import math
path = 'FLFLFFFLFFLFLFFRFFFFFFFFFRFFLFFLFFFFRFFFRFRFLFRFFFFRFFRFFFFFFLFFFLFFFFFLFFFFFFFFRFLFFFFFRFFLFLFRFFFFFFRFLFFFFRFRFFFFFFFFLFLFFFFFLFLFLFFFLFRFRFLFLFFRFFRFFFLFFLFFFLFFFFRFRFFRFFLFFFFFFFFFFRFFFFFFRFRFRFFFRFFLFFLFFFFFFFFFFFFFFFFFFFFFFFRFRFRFRFFLFFLFFFFLFFFRFRFLFFRFRFFFFFRFFRFRFFRFLFLFFFFFFFFFFLFFLFFFFFFFLFLFFFFLFLFRFLFRFFFRFFFFFRFFLFRFLFFRFFLFFFRFFLFFFFRFRFFFRFFFFLFFFLFFFRFFLFFLFRFRFRFFFRFFLFFRFFRFFLFLFFFFFFFF'
distance = []
for i in range(150):
	position = 0+0j
	d = 0 # 0= north
	for direction in path:
		if direction == 'F' and d%4 == 0: 
			position += 1j
		if direction == 'F' and d%4 == 1: # 1 =east
			position += 1
		if direction == 'F' and d%4 == 2: # 2 =south
			position -= 1j
		if direction == 'F' and d%4 == 3: # 3 =west
			position -= 1
		if direction == 'L':
			if random.random() > 0.55:
				d -= 1
		if direction == 'R':
			if random.random() > 0.55:
				d += 1
	distance.append(math.sqrt(position.real*position.real+position.imag*position.imag))

if sum(distance)/len(distance)>37:
	print("euthanize the rover")

