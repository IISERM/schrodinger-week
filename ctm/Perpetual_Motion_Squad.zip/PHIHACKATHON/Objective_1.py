#net_fuel= input()
#cylinders=input()
net_fuel=4
cyl= [1,2,3]
l= len(cyl)

def numofways(net_fuel, cylinder, l ):

    if (net_fuel == 0):
        return 1

    if (net_fuel < 0):
        return 0;


    if (l <=0 and net_fuel >= 1):
        return 0

    return count( S, m - 1, n ) + count( S, m, n-S[m-1] );

count(cyl,3,4)
