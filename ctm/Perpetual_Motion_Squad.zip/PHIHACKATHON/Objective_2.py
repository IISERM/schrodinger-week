import numpy as np
import matplotlib.pyplot as plt



D = 30
r = 50
d = 0.2
kT = 1000
num_steps = 2*(10**5)
num_particles = 50

initial_position = np.array([np.random.random(2)*4-2 for _ in range(num_particles)])
plt.scatter(*zip(*initial_position))
plt.show()
# for best results, set the limits of the plot (-3*D, 3*D) for both axes
def E(dist):
    return D*((r/dist)**12-(r/dist)**6)

def dist(x,y):
    return np.linalg.norm(x-y)

def P_cont(E1,E2):
    if E2 <  E1:
        return 1
    else:
        return np.exp(-(E2-E1)/kT)



#step 1
def random_motion(arr):
    changed = np.copy(arr)
    particle = np.random.randint(50)
    shift = np.random.uniform(-d,d)
    changed[particle][0] += shift
    changed[particle][1] += shift

    return changed


#step 2
def pairs(arr):
    return [(arr[i],arr[j]) for i in range(len(arr)) for j in range(i+1, len(arr))]

def potential_energy(system):
    E_dash = 0
    pairs = [(system[i],system[j]) for i in range(len(system)) for j in range(i+1, len(system))]
    for pair in pairs:
        distance = dist(pair[0],pair[1])
        print(distance)
        E_dash += E(distance)
    return E_dash

#main
for i in range(num_steps+1):
    changed_position=random_motion(initial_position)
    E1 = potential_energy(initial_position)
    E2 = potential_energy(changed_position)
    P = P_cont(E1,E2)
    if np.random.uniform(0,1) < P:
        initial_position = changed_position
    else:
        pass
    if i%1000 == 0:
        plt.scatter(*zip(*initial_position))
        name = str(i)+".png"
        plt.savefig(name)
