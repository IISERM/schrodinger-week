import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

bodies = {'Planet 0':[ 0.0, 0.0, 0.0], 'Planet 1':[4.08843, 4.69975 , 5.41835 ], 'Planet 2':[ 1.01513, 5.89078, 1.48675], 'Planet 3':[6.04748, 3.76679, 5.91324], 'Planet 4':[1.18806, 3.26168, 4.75359 ], 'Planet 5':[5.81472, 3.50833, 3.5276], 'Planet 6':[1.78623, 1.80381, 4.97739], 'Planet 7':[-0.618259, 6.18706, 3.0477],'Planet 8':[1.3763, 3.78712, 5.16773],'Planet 9':[5.68307, 4.41375, 5.18493],'Planet 10':[1.27576, 5.36594, 3.70002], 'WH1':[2.0, 3.0, 4.0 ], 'WH2':[0.0 ,5.0 ,2.5], 'WH3': [5.0, 5.0, 5.0]}

G= nx.Graph()
nodes = [x for x in bodies]
edges = [(nodes[i],nodes[j]) for i in range(len(nodes)) for j in range(i+1, len(nodes))]
G.add_nodes_from(nodes)




weights = {}
for i in edges:
    x = np.array(bodies[i[0]])
    y = np.array(bodies[i[1]])
    weight = np.linalg.norm(x-y)
    weights[i] = weight
weights[("WH1","WH2")] = 0
weights[("WH2","WH3")] = 0
weights[("WH1","WH3")] = 0

for edge in edges:
    G.add_edge(edge[0],edge[1],weight = weights[edge])

print(G.nodes())


C = []
for i in nodes:
    l=[]
    for j in nodes:
        if i == j:
            l.append(0)
        if nodes.index(i) < nodes.index(j):
            l.append(weights[(i,j)])
        if nodes.index(i) > nodes.index(j):
            l.append(weights[(j,i)])
    C.append(l)
print(C)


WH=['WH1',"WH2","WH3"]


def shortestpath(v):
    l=[]
    for node in nodes:
        l.append(C[v][node])
    n = nodes[l.index(min(l))+ 1]


#def held_Karp_mod(G)    
